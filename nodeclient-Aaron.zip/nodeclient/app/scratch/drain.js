const SERIAL_NUMBER = "TC51_16086522502306";

let _startingBatteryLevel = 100;
let _drainBatteryByPercentageOverTime = 0.05;
let _currentBatteryLevel = 100;

function getRandomBatteryLevel(min, max) {
  return Math.random() * (max - min) + min;
}

function getRandomBatteryDrainPercentage(min, max) {
  let num = Math.random() * (max - min) + min;
  return truncateDecimals(num, 3);

  //return Math.round(num * 100) / 100;
}

function truncateDecimals(num, decimals) {
  var factor = Math.pow(10, decimals);
  return Math.trunc(num * factor) / factor;
}

function getAdjustingBatterLevel(min, max) {}

const getBattery = () => {
  var min = 0;
  var max = 100;

  var drainPercentage = getRandomBatteryDrainPercentage(0.001, 0.005);
  console.log(`Draining battery by ${drainPercentage}`);

  _currentBatteryLevel =
    _currentBatteryLevel - _currentBatteryLevel * drainPercentage;

  console.log(`Current Battery Reading ${_currentBatteryLevel}`);
};

setInterval(() => {
  getBattery();
}, 1000);

const getRandomBatteryLevel = (min, max) => {
  return Math.random() * (max - min) + min;
};

module.exports = {
  getRandomBatteryLevel
};

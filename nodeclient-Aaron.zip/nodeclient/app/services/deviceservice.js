let SERIAL_NUMBER = "TC51_16086522502306";

let _currentBatteryLevel = 100;
const _batteryDrainPercentageMin = 0.001;
const _batteryDrainPercentageMax = 0.005;
let _numberOfTimesPolled = 0;

function getRandomBatteryDrainPercentage(min, max) {
  let num = Math.random() * (max - min) + min;
  //return Math.round(num * 100) / 100; 2 decimal places
  return truncateDecimals(num, 3);
}

function truncateDecimals(num, decimals) {
  var factor = Math.pow(10, decimals);
  return Math.trunc(num * factor) / factor;
}

function getRandomBatteryLevel(min, max) {
  return Math.random() * (max - min) + min;
}

function getBatteryReading() {
  var drainPercentage = getRandomBatteryDrainPercentage(
    _batteryDrainPercentageMin,
    _batteryDrainPercentageMax
  );
  //console.log(`Draining battery by ${drainPercentage}`);

  if (_numberOfTimesPolled === 12) {
    //simulate a sudden drop in Battery level after the 12th poll
    _currentBatteryLevel = _currentBatteryLevel - 15;
  }

  if (_currentBatteryLevel < 10) {
    //Act as if the battery was recharged back to 100%
    _currentBatteryLevel = 100;
    _numberOfTimesPolled = 0;
  }

  _currentBatteryLevel =
    _currentBatteryLevel - _currentBatteryLevel * drainPercentage;
  return _currentBatteryLevel;
}

function getDeviceInfo() {
  return {
    _dv: [
      {
        _t: "device_info",
        _v: {
          display_vendor_id: "0",
          keyboard_type: "5",
          touch_panel_vendor_id: "0",
          wlan_radio_name: "8",
          hardware_revision_number: "0",
          scan_engine_version_name: "2048",
          version_incremental: "4",
          user: "jenksvc",
          brand: "Zebra",
          model: "TC51",
          product: "TC51",
          device: "TC51",
          version_sdk: 25,
          host: "z17sp-gitapp04",
          display: "01-01-49-NN-00-A",
          boot_loader: "B01-00200.2-D1",
          finger_print:
            "Zebra/TC51/TC51:7.1.2/01-01-49-NN-00-A/1:user/release-keys",
          tags: "release-keys",
          manufacturer: "Zebra Technologies",
          serial_number: SERIAL_NUMBER,
          hardware: "qcom",
          id: "01-01-49-NN-00-A",
          board: "msm8952",
          version_release: "7.1.2",
          mac: "94:fb:29:29:1f:19",
          automatic_date_time: true,
          timezone: "America/New_York",
          automatic_time_zone: true,
          cpu_abi0: "arm64-v8a",
          cpu_abi1: "armeabi-v7a",
          cpu_abi2: "armeabi",
          total_disk_size: 3583422464,
          total_physical_memory: 3808718848,
          number_of_processors: 6,
          cfe: "3",
          cpl: "0",
          spl: "2017-12-05"
        },
        _r: Date.now()
      }
    ],
    _dn: "DataAnaltyicsDca"
  };
}

function getBatteryInfo() {
  //battery_property_current_average was causing a warning, so temporarily
  //removed from json data
  //: -9223372036854776000,
  return {
    _dv: [
      {
        _t: "battery",
        _v: {
          battery_type: 201,
          battery_health_percentage: 100,
          battery_present_capacity: 5206,
          battery_present_charge: 882,
          battery_time_to_empty: 5782,
          battery_time_to_full: 65535,
          battery_level: getBatteryReading(),
          battery_status: 3,
          battery_temperature: 220,
          battery_voltage: 3622,
          ac_line_status: 0,
          battery_charge_source: 0,
          battery_serial_number: "P0610",
          battery_manufacturing_date: "2018-04-26",
          battery_partnumber: "BT-000337-01 R.C"
        },
        _r: Date.now()
      }
    ],
    _dn: "DataAnaltyicsDca"
  };
}

function getBatteryEvents() {
  return {
    _dv: [
      {
        _t: "battery_events",
        _r: Date.now(),
        _v: {
          action: "100",
          battery_level: "15",
          battery_manufacturing_date: "2018-04-26",
          battery_partnumber: "BT-000337-01 R.C",
          battery_serial_number: "P0610"
        }
      }
    ],
    _dn: "battery_events"
  };
}

function getFlashHealth() {
  return {
    _dv: [
      {
        _t: "flash_health",
        _r: Date.now(),
        _v: {
          manufacturer: "Hynix",
          preEOLInfo: "1",
          lifeTime: "1",
          extCSDVersion: "8",
          emmcMode: "PSLC",
          emmcSize: "16",
          serialID: "1447466477"
        }
      }
    ],
    _dn: "flash_health"
  };
}

function getFlashStats() {
  return {
    _dv: [
      {
        _t: "flash_stats",
        _v: {
          availablebytes: "9020579840",
          totalbytes: "9249509376"
        },
        _r: Date.now()
      },
      {
        _t: "ram_stats",
        _v: {
          availablebytes: 2563280896,
          totalbytes: 3808718848
        },
        _r: Date.now()
      }
    ],
    _dn: "DataAnaltyicsDca"
  };
}

function getDeviceHeaderInfo() {
  const epochNow = Date.now();
  var _h = {
    _m: "TC51",
    _sn: SERIAL_NUMBER,
    _sa: epochNow,
    _rt: epochNow,
    _ip: "155.63.0.254"
  };
  return _h;
}

const retrieveAllDeviceDataAsync = async device_id => {
  SERIAL_NUMBER = device_id;
  console.log(
    `retrieving all data about the device for device_id ${SERIAL_NUMBER}`
  );

  _numberOfTimesPolled++;

  let allDeviceData = [];

  let batteryInfo = getBatteryInfo();
  let deviceInfo = getDeviceInfo();
  let batteryEvents = getBatteryEvents();
  let flashStats = getFlashStats();
  let flashHealth = getFlashHealth();

  allDeviceData.push(batteryInfo);
  allDeviceData.push(deviceInfo);
  allDeviceData.push(batteryEvents);
  allDeviceData.push(flashStats);
  allDeviceData.push(flashHealth);

  return allDeviceData;
};

const retrieveBatteryDataAsync = async device_id => {
  SERIAL_NUMBER = device_id;
  console.log("retrieving battery data...");
  return getBatteryInfo();
};

const retrieveDeviceHeaderDataAsync = async device_id => {
  SERIAL_NUMBER = device_id;
  console.log("retrieving device header data...");
  return getDeviceHeaderInfo();
};

module.exports = {
  retrieveDeviceHeaderDataAsync,
  retrieveBatteryDataAsync,
  retrieveAllDeviceDataAsync
};

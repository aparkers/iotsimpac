var Mqtt = require("azure-iot-device-mqtt").Mqtt;
var DeviceClient = require("azure-iot-device").Client;
var Message = require("azure-iot-device").Message;
const helpers = require("../utils/helpers");

// Using the Azure CLI:
// az iot hub device-identity show-connection-string --hub-name {YourIoTHubName} --device-id MyNodeDevice --output table

const sendDeviceData = (connectionString, deviceData) => {
  var client = DeviceClient.fromConnectionString(connectionString, Mqtt);

  let message = new Message(JSON.stringify(deviceData));

  //let batteryLevel = getRandomBatteryLevel(0, 100);
  // Add a custom application property to the message.
  // An IoT hub can filter on these properties without access to the message body.
  //message.properties.add("batteryAlert", batteryLevel < 20 ? "true" : "false");
  message.properties.add("project", "savannah");

  //for testing purposes, randomly add a battery alert so we can test
  //custom routing rules

  //var level = helpers.getRandomBatteryLevel(1, 20);
  var level = getBatteryReading(deviceData);
  console.log(`current battery level ${level}...`);
  message.properties.add("batteryAlert", level < 25 ? "true" : "false");

  console.log("Sending device data to Iot Hub: " + message.getData());

  client.sendEvent(message, function(err) {
    if (err) {
      console.error("Send device data error: " + err.toString());
    } else {
      console.log("device data sent");
    }
  });
};

const getBatteryReading = deviceData => {
  var batteryLevel = 0;
  if (deviceData && deviceData._b && deviceData._b.length > 0) {
    deviceData._b.forEach(value => {
      //console.log(`value:  ${JSON.stringify(value)}`);
      //target battery node:
      if (value._dv) {
        value._dv.forEach(dvValue => {
          switch (dvValue._t) {
            case "battery":
              let batteryData = dvValue._v;
              //console.log(`BatteryInfo: ${JSON.stringify(batteryData)}`);
              batteryLevel = batteryData.battery_level;
              break;
            case "battery_events":
              let batteryEvents = dvValue._v;
            //console.log(`BatteryEvents: ${JSON.stringify(batteryEvents)}`);
            default:
            //console.log(`dvValue._t == ${dvValue._t}`);
          }
        });
      }
    });
  }
  return batteryLevel;
};

module.exports = {
  sendDeviceData
};

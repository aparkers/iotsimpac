"use strict";
const deviceService = require("./services/deviceservice");
const iotHubService = require("./services/iothubservice");
const yargs = require("yargs");

const argv = yargs
  .command("process", "Process device scanner information", {
    device_id: {
      describe: "Specific unique device id",
      demand: true,
      alias: "d"
    },
    connection: {
      describe: "Connection string for the device to the Azure Iot Hub",
      demand: true,
      alias: "c"
    },
    interval: {
      describe:
        "How often in milliseconds to send device data to Azure Iot Hub",
      demand: false,
      alias: "i"
    }
  })
  .help().argv;

let device_id = "";
let connection = "";
let interval = 2000;

//command:  process
//args:  -d 'TC51_16086522502306' -c 'HostName=ZebraSavIotHub.azure-devices.net;DeviceId=TC51_16086522502306;SharedAccessKey=3SwTyuBhqR0ynALGi1THp5DdydyWJchCviTdpGs08YM=' -i 2000

// Zebra Subscription
//connection =
//  "HostName=ZebraSavIotHub.azure-devices.net;DeviceId=TC51_16086522502306;SharedAccessKey=3SwTyuBhqR0ynALGi1THp5DdydyWJchCviTdpGs08YM=";

//connection =
//  "HostName=ClZebraSavIotHub.azure-devices.net;DeviceId=TC51_16086522502306;SharedAccessKey=xyEz+DCXwzfsqUUZhtWwaNowtXaW/8y2d8At1k+7DjM=";

device_id = argv.device_id;
connection = argv.connection;

if (argv.interval) {
  interval = argv.interval;
}

// console.log(
//   `interval: ${interval} device_id ${device_id} connection ${connection}`
// );

// Create a message and send it to the IoT hub every 5 seconds
setInterval(() => {
  getDeviceInfo();
}, interval);

const getDeviceInfo = async () => {
  let deviceHeaderInfo = await deviceService.retrieveDeviceHeaderDataAsync(
    device_id
  );
  let allDeviceInfo = await deviceService.retrieveAllDeviceDataAsync(device_id);

  let deviceMessage = {
    _h: "",
    _b: []
  };

  deviceMessage._h = deviceHeaderInfo;
  deviceMessage._b = allDeviceInfo;

  if (allDeviceInfo && allDeviceInfo.length > 0) {
    console.log(`count of info ${allDeviceInfo.length}`);
    //message will have a "_h" and "_b" as such:
    // {
    //     "_h" = {
    //         "_sn" : "18103523022358",
    //         "_sa": 1534768608527,
    //         "_rt": 1534768607901,
    //         "_ip": "155.63.0.254"
    //     },
    //     "_b" = [
    //         {
    //             "_dv": [],
    //             "_dn": "tag (i.e. battery)"
    //         }
    //     ]
    // }
    // console.log(
    //   `The deviceMessage structure:  ${JSON.stringify(deviceMessage)}`
    // );

    iotHubService.sendDeviceData(connection, deviceMessage);

    // allDeviceInfo.forEach(value => {
    //   //target battery node:
    //   if (value._dv) {
    //     value._dv.forEach(dvValue => {
    //       switch (dvValue._t) {
    //         case "battery":
    //           let batteryData = dvValue._v;
    //           console.log(`BatteryInfo: ${JSON.stringify(batteryData)}`);
    //         case "battery_events":
    //           let batteryEvents = dvValue._v;
    //           console.log(`BatteryEvents: ${JSON.stringify(batteryEvents)}`);
    //         default:
    //           console.log(`dvValue._t == ${dvValue._t}`);
    //       }
    //     });
    //   }
    // });
  } else {
    console.log("Unable to retrieve All device info");
  }
};
